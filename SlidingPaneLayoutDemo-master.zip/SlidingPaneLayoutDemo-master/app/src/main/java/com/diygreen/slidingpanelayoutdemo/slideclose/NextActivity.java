package com.diygreen.slidingpanelayoutdemo.slideclose;

import android.os.Bundle;

import com.diygreen.slidingpanelayoutdemo.R;

public class NextActivity extends BaseSlideCloseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);
    }
}
