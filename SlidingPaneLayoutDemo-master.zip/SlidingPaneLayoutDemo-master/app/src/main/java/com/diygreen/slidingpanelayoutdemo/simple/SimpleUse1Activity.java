package com.diygreen.slidingpanelayoutdemo.simple;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.diygreen.slidingpanelayoutdemo.R;

public class SimpleUse1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simpleuse1);
    }
}
