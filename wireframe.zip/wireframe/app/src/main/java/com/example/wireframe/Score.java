package com.example.wireframe;

public class Score {
	
	public String date;// 日期
	public int score;// 分数
	public int total;// 数量
	
}
